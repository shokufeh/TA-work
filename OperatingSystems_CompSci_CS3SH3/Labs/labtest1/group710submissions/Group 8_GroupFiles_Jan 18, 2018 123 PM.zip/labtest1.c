//Jakub Pawlikowski #400011899 
//Justin Vu 1403210

#include <sys/types.h> 
#include <stdio.h> 
#include <unistd.h>

int main()
{
	printf("%d\n", getpid());
	pid_t pid;
	pid = fork();
	
	if (pid == 0) {
		printf("%d\n", getpid());
		pid_t pid1;
		pid1 = fork();
		if (pid1 == 0) {
			printf("%d\n", getpid());
			pid_t pid2;
			pid2 = fork();
			if (pid2 == 0){
				printf("%d\n", getpid());
				pid_t pid3;
				pid3 = fork();
				if (pid3 == 0){
					printf("%d\n", getpid());
				} else {
					wait();}
					
			} else {
				wait();}			
		} else {
			wait();}	
				
	} else {
		wait();}

	return 0;
}