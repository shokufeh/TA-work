/*
Labtest `
Mingnan Su 400016478
Jiuwei Wang 400061882
Group 7
*/

#include <stdio.h>
#include  <sys/types.h> /* This header file has the definition for pid_t type*/

int main()
{
	pid_t pid;	
	pid = fork();
	printf("%d\n",getpid());
	if(pid == 0) {
		pid_t pid1=fork();
		if(pid1 == 0) {
			printf("%d\n",getpid());
			pid_t pid2=fork();
			if(pid2 == 0){
				printf("%d\n",getpid());
				pid_t pid3 = fork();
				if(pid3 == 0){
					printf("%d\n",getpid());
				}else{wait();}
			}else{wait();}
		}else{wait();}
	}else{wait();}
	return 0;
}
