/**
 * Author: Danny Stewart, Dustin Jurkaulionis
 * Course: Operating Systems CS 3SH3, Winter 2018
 * LabTest1
 */

#include <stdio.h>
#include  <sys/types.h> 

int main()
{
	pid_t pid, pid1,pid2, pid3, pid4;	
	printf("%d\n",getpid());
	pid = fork();
	
	if(pid == 0) {
		printf("%d\n", getpid());
		pid1 = fork();
		if(pid1 == 0){
			printf("%d\n", getpid());
			pid2 = fork();
			if(pid2 == 0){
				printf("%d\n", getpid());
				pid3 = fork();
				if (pid3 == 0){
					printf("%d\n", getpid());
				}
				else{wait(); }
			}
			else {wait(); }
		}
		else{wait();}
	}
	else
	{wait(); }
	return 0;

}