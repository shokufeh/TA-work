//James Militante militajo 001327968
//Anthony Xavier Mella mellaa 400019353

#include <stdio.h>
#include  <sys/types.h>

int main(){
  printf("%d\n", getpid());
  pid_t pid = fork();
  if (pid == 0){
    printf("%d\n", getpid());
    pid_t pid2 = fork();
    if (pid2 == 0){
      printf("%d\n",getpid());
      pid_t pid3 = fork();
      if (pid3 == 0){
        printf("%d\n",getpid());
        pid_t pid4 = fork();
        if (pid4 == 0){
          printf("%d\n",getpid());
        }else{
          wait();
        }
      }else{
        wait();
      }
    }else{
      wait();
    }
  }else{
    wait();
  }

}
