#include <stdio.h>
#include  <sys/types.h> /* This header file has the definition for pid_t type*/

int main(){
	pid_t pid=fork(); // P1 P2 created
	printf("%d\n",getpid()); // print P1, P2 pids
	if (pid==0){
		pid_t pid1=fork(); //P3 created
		if(pid1==0){
			printf("%d\n",getpid()); //print P3
			pid_t pid2=fork(); //P4 created
			if(pid2==0){
				printf("%d\n",getpid()); //print P4
				pid_t pid3=fork(); //P5 created
				if(pid3==0){
					printf("%d\n",getpid()); //print P5
				}else{
					wait();
				}
			}else{
				wait();
			}
		}else{
			wait();
		}
	}else{
		wait();
	}
	return 0;
}