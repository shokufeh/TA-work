// Tasnim Noshin - 400043624
// Umme Salma Gadriwala - 400021431

#include <stdio.h>
#include <sched.h>
#include <linux/kernel.h>
#include <sys/types.h>


int main() {

	printf("%d\n", getpid()); // p1
	pid_t pid2 = fork(); // create p2

	if (pid2 == 0) { // p2 process
		printf("%d\n", getpid()); // p2
		pid_t pid3 = fork(); // create p3
		if (pid3 == 0) {
			printf("%d\n", getpid()); // p3
			pid_t pid4 = fork(); // create p4
			if (pid4 == 0) {
				printf("%d\n", getpid()); // p4
				pid_t pid5 = fork(); // create p5
				if (pid5 == 0) {
					printf("%d\n", getpid()); // p5
				} else { wait(); }
			} else { wait(); }
		} else { wait(); }
	} else { wait(); }
	return 0;
}