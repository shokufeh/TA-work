/*

Names: Rumsha SIddiqui (400020188), Teo Voinea (1409586)
Lab Test 1 - Jan 18, 2018

*/

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main()
{
	printf("%d\n", getpid());
	pid_t pid;

	pid = fork();
	
	if (pid == 0) { /* p2 */
		printf("%d\n", getpid());
		pid_t pid2;
		pid2 = fork();

		if (pid2 == 0) { //p3
			printf("%d\n", getpid());
			pid_t pid3;
			pid3 = fork();
			
			if (pid3 == 0) { //p4
				printf("%d\n", getpid());
				pid_t pid4;
				pid4 = fork();
				if (pid4 == 0) { //p5
					printf("%d\n", getpid());
					return 0;
				}
				else if (pid4 > 0) { //p4
					wait(NULL);
					return 0;
				}
				else {
					printf("Failed to fork from p4");
				}			
			}
			else if (pid3 > 0) { //p3
				wait(NULL);
			}
			else {
				printf("Failed to fork from p3");
			}
			return 0;
		}
		else if (pid2 > 0) { // p2
			//pid2
			wait(NULL);
			return 0;
		}	
		else {
			printf("Failed to fork from p2");
		}
	}
	else if (pid > 0) { /* parent process */
		wait(NULL);
		//printf ("PARENT "); /* LINE A */
		return 0;
	}
}
