#include <stdio.h>
#include <sys/types.h>

// main method
int main() {
	printf("%d\n", getpid()); // format string
	pid_t pid2 = fork(); // fork to create child
	if (pid2 == 0) { // check that child is executing (multiple levels)
		printf("%d\n", getpid());
		pid_t pid3 = fork();
		if (pid3 == 0) {
			printf("%d\n", getpid());
			pid_t pid4 = fork();
			if (pid4 == 0) {
				printf("%d\n", getpid());
				pid_t pid5 = fork();
				if (pid5 == 0) {
					printf("%d\n", getpid());
				} else {
					wait(); // wait for child
				}
			} else {
				wait();
			}
		} else {
			wait();
		}
	} else {
		wait();
	}
	return 0;
}
