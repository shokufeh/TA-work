/*Bartosz Kosakowski
400028494
Partner: Aushim Lakhana
Lab test 1
*/
#include <stdio.h>
#include <sys/types.h>

int main(){
	pid_t pid0;
	pid0 = fork();
	if (pid0 == 0){
		printf("%d\n", getpid());
		pid_t pid1 = fork();
		if (pid1 == 0){
			printf("%d\n", getpid());
			pid_t pid2 = fork();
			if (pid2 == 0){
				printf("%d\n", getpid());
				pid_t pid3 = fork();
				if (pid3 == 0){
					printf("%d\n", getpid());
				}
				else{
					wait();
				}
			}
			else{
				wait();
			}
		}
		else{
			wait();
		}

	}
	else{
		printf("%d\n", getpid());
		wait();
	}
	return 0;
}